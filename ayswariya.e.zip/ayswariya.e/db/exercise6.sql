DELETE FROM edu_semester_fee where stud_id in (1,9,2,5,10,3,20,18,6,18,19,17);

INSERT INTO edu_semester_fee (cdept_id,stud_id,semester,amount,paid_year,paid_status)
			VALUES	(1,1,2,37000,null,"unpaid"),
						(9,2,2,37000,null,"unpaid"),
						(9,3,2,37000,null,"unpaid"),
						(2,5,3,36000,null,"unpaid"),
						(2,6,3,36000,null,"unpaid"),
						(5,9,3,36000,null,"unpaid"),
						(5,10,3,36000,null,"unpaid"),
						(10,17,4,39000,null,"unpaid"),
						(10,18,4,39000,null,"unpaid"),
						(3,19,5,50000,null,"unpaid"),
						(3,20,5,50000,null,"unpaid");

SELECT * FROM edu_semester_fee;
				