CREATE TABLE edu_university 
							( univ_code CHAR(4) PRIMARY KEY
							, university_name VARCHAR(100) NOT NULL
							);

CREATE TABLE edu_designation
									( id INT PRIMARY KEY AUTO_INCREMENT
									,`name` VARCHAR(30) NOT NULL
									, rank CHAR(1) NOT NULL
									);						
									
CREATE TABLE edu_department
								( dept_code CHAR(4) PRIMARY KEY
								, dept_name VARCHAR(50) NOT NULL
								, univ_code CHAR(4) 
								, KEY fk_univ_code (univ_code)
							   , CONSTRAINT fk_dep_univ_code FOREIGN KEY (univ_code)
							     REFERENCES edu_university(univ_code)
								);		
								
CREATE TABLE edu_college
							 ( id INT PRIMARY KEY AUTO_INCREMENT
							 , univ_code CHAR(4)
							 , CONSTRAINT fk_col_univ_code FOREIGN KEY (univ_code)
							   REFERENCES edu_university(univ_code)
							 ,`code` CHAR(4) NOT NULL
						 	 ,`name` VARCHAR(100) NOT NULL
							 , city VARCHAR(50) NOT NULL
							 , state VARCHAR(50) NOT NULL
							 , year_opened YEAR(4) NOT NULL
							 );
							 
CREATE TABLE edu_college_department
								( cdept_id INT PRIMARY KEY AUTO_INCREMENT
								, udept_code CHAR(4)
								, KEY fk_udept_code (udept_code)
								, CONSTRAINT fk_coldept_udeptcode FOREIGN KEY (udept_code)
								  REFERENCES edu_department (dept_code)
								, college_id INT 
								, KEY fk_col_id (college_id)
								, CONSTRAINT fk_coldept_col_id FOREIGN KEY (college_id)
								  REFERENCES edu_college (id)	 
								);
								
CREATE TABLE edu_employee		
								( id INT PRIMARY KEY AUTO_INCREMENT
								, college_id INT
								, CONSTRAINT fk_emp_col_id FOREIGN KEY (college_id)
								  REFERENCES edu_college (id)
								, cdept_id INT
								, CONSTRAINT fk_emp_cdept_id FOREIGN KEY (cdept_id)
								  REFERENCES edu_college_department (cdept_id)
								, desig_id INT
								, CONSTRAINT fk_emp_desig_id FOREIGN KEY (desig_id)
								  REFERENCES edu_designation(id) 
								, `name` VARCHAR(100) NOT NULL
								, dob DATE NOT NULL
								, email VARCHAR(50) NOT NULL
								, phone BIGINT NOT NULL
								);	
								
CREATE TABLE edu_student
								( id INT PRIMARY KEY AUTO_INCREMENT
								, cdept_id INT
								, CONSTRAINT stu_cdept_id FOREIGN KEY (cdept_id)
								  REFERENCES edu_college_department (cdept_id)
								, college_id INT
								, CONSTRAINT fk_stu_college_id FOREIGN KEY (college_id)
								  REFERENCES edu_college (id)
								, roll_number CHAR(8) NOT NULL
								, `name` VARCHAR(100) NOT NULL
								, dob DATE NOT NULL
								, gender CHAR(1) NOT NULL
								, email VARCHAR(50) NOT NULL
								, phone BIGINT NOT NULL
								, address VARCHAR(200) NOT NULL
								, academic_year YEAR(4) NOT NULL
								);
								
CREATE TABLE edu_syllabus
				( id INT PRIMARY KEY AUTO_INCREMENT
				, cdept_id INT
				, CONSTRAINT fk_syll_cdeptid FOREIGN KEY (cdept_id)
				  REFERENCES edu_college_department (cdept_id)
				, syllabus_code CHAR(4) NOT NULL
				, syllabus_name VARCHAR(100) NOT NULL
				);	
				
CREATE TABLE edu_professor_syllabus
				( emp_id INT
				, CONSTRAINT fk_profsyll_empid FOREIGN KEY (emp_id)
				  REFERENCES edu_employee (id)
				, syllabus_id INT 
				, CONSTRAINT fk_profsyll_syllid FOREIGN KEY (syllabus_id)
				  REFERENCES edu_syllabus (id)
				, semester TINYINT NOT NULL
				);	
		
CREATE TABLE edu_semester_fee
					( cdept_id INT 
					, CONSTRAINT fk_semfee_cdeptid FOREIGN KEY (cdept_id)
				     REFERENCES edu_college_department (cdept_id)
					, stud_id INT
					, KEY stud_id (stud_id)
					, CONSTRAINT fk_semfee_studid FOREIGN KEY (stud_id)
				     REFERENCES edu_student (id)
					, semester TINYINT NOT NULL
					, amount DOUBLE(18,2) NULL
					, paid_year YEAR(4) NULL
					, paid_status VARCHAR(10) NOT NULL
					);	
					
CREATE TABLE edu_semester_result
										( stud_id INT
										, CONSTRAINT fk_semres_studid FOREIGN KEY (stud_id)
				                    REFERENCES edu_student (id)
										, syllabus_id INT
										, CONSTRAINT fk_semfee_syllid FOREIGN KEY (syllabus_id)
				                    REFERENCES edu_syllabus (id)
										, semester TINYINT NOT NULL
										, grade VARCHAR(2) NOT NULL
										, credits FLOAT NOT NULL
										, result_date  DATE NOT NULL
										);
										
