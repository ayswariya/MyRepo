SELECT univ.univ_code,univ.university_name,desig.rank,dep.dept_name
		FROM edu_employee AS emp 
				INNER JOIN edu_designation AS desig ON emp.desig_id=desig.id
				INNER JOIN edu_college AS col ON emp.college_id=col.id
				INNER JOIN edu_university AS univ ON col.univ_code=univ.univ_code
				INNER JOIN edu_department AS dep ON univ.univ_code=dep.univ_code;