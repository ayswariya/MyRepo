SELECT col.code,col.name,univ.university_name,col.city,col.state, col.year_opened,dep.dept_name,desig.name
		FROM edu_college AS col
			INNER JOIN edu_university AS univ ON col.univ_code=univ.univ_code
			INNER JOIN edu_department AS dep ON univ.univ_code=dep.univ_code
			INNER JOIN edu_college_department AS coldep ON col.id=coldep.college_id
			INNER JOIN edu_employee AS emp ON coldep.cdept_id=emp.cdept_id
			INNER JOIN edu_designation AS desig ON desig.id=emp.desig_id
			WHERE dept_name IN ('compute science engineering','information technology')
			AND desig.name='hod';