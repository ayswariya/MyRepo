SELECT emp.id,emp.name,emp.dob,emp.email,emp.phone,col.id,col.name,col.univ_code,col.city,
		 col.state,col.year_opened,desig.rank
	FROM edu_employee AS emp
		INNER JOIN edu_designation AS desig ON emp.desig_id=desig.id
		INNER JOIN edu_college AS col ON emp.college_id=col.id
		INNER JOIN edu_university AS univ ON col.univ_code=univ.univ_code
		INNER JOIN edu_college_department AS coldep ON emp.cdept_id=coldep.cdept_id
		WHERE univ.university_name='anna university' 
		ORDER BY col.name,desig.rank ASC; 