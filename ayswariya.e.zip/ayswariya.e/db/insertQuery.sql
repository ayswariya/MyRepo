INSERT INTO edu_university (univ_code,university_name) VALUES ('au01',"anna university");
INSERT INTO edu_university (univ_code,university_name) VALUES ('pu02',"periyar university");
INSERT INTO edu_university (univ_code,university_name) VALUES ('mu03',"madras university");

INSERT INTO edu_designation (`name`,rank) 
				VALUES		
						('principal','a'),
						('hod','b'),
						('professor','c');		
						
INSERT INTO edu_department (dept_code,dept_name,univ_code)	
	VALUES 
		('itau','information technology','au01'),
		('csau','compute science engineering','au01'),
		('ecau','elctronics and communication engineering','au01'),
		('eeau','electricals and electronics engineering','au01'),
		('itpu','information technology','pu02'),
		('cspu','compute science engineering','pu02'),
		('ecpu','elctronics and communication engineering','pu02'),
		('itmu','information technology','mu03'),
		('csmu','compute science engineering','mu03')
		
INSERT INTO edu_college (univ_code,`code`,`name`,city,state,year_opened)
	VALUES
		    ('au01','c001','guindy college of engineering','chennai','tamilnadu',1989)
		  , ('au01','c002','srm college of engineering','chennai','tamilnadu',1990)
		  , ('pu02','c003','meenakshi sundararajan engineering college','chennai','tamilnadu',1999)
		  , ('pu02','c004','karpagam college of engineering','coimbatore','tamilnadu',1998)
		  , ('mu03','c005','christian college of engineering','vellore','tamilnadu',1999)
		  
INSERT INTO edu_college_department (udept_code,college_id)
		VALUES
				('itau','1'),
				('csau','1'),
				('ecau','1'),
				('itau','2'),
				('csau','2'),
				('eeau','2'),
				('itpu','3'),
				('ecpu','3'),
				('itpu','4'),
				('cspu','4'),
				('csmu','5'),
				('itmu','5');
				
INSERT INTO edu_employee (college_id,cdept_id,desig_id,`name`,dob,email,phone)
	VALUES
			(1,1,2,'sam','1988-05-02','sam@gmail.com','7854965873'),				
			(1,1,3,'ram','1985-09-14','ram@gmail.com','7521515873'),
			(1,2,2,'sri','1991-11-02','sri@gmail.com','7356248913'),
			(1,2,3,'sai','1999-08-03','sai@gmail.com','8584784055'),	
			(1,3,2,'zahir','1997-05-12','zahir@gmail.com','7708965483'),	
			(1,3,3,'samantha','1992-06-14','samantha@gmail.com','9589658973'),
			(2,4,2,'riya','1980-07-22','riya@gmail.com','9988568873'),
			(2,4,3,'smith','1986-08-25','smith@gmail.com','7744545543'),	
			(2,5,2,'steve','1984-09-08','steve@gmail.com','8545545879'),	
			(2,5,3,'tamil','1990-10-06','tamil@gmail.com','9952465873'),	
			(2,6,2,'carol','1989-01-07','carol@gmail.com','8529635875'),
			(2,6,3,'ross','1991-02-17','ross@gmail.com','9874565876'),
			(3,7,2,'rachel','1990-03-15','rachel@gmail.com','7391852460'),	
			(3,7,3,'monica','1991-04-14','monica@gmail.com','8896465889'),		
			(3,8,2,'simran','1996-08-30','simran@gmail.com','7896545800'),	
			(3,8,3,'pheobe','1992-04-30','pheobe@gmail.com','7848589643'),
			(4,9,2,'joey','1987-01-18','joey@gmail.com','8975965825'),
			(4,9,3,'chandler','1989-07-24','chandler@gmail.com','8957322563'),
			(4,10,2,'swathi','1996-11-19','swathi@gmail.com','8957225583'),
			(4,10,3,'joy','1994-12-28','joy@gmail.com','7889547853'),	
			(5,11,2,'ziva','1991-10-31','ziva@gmail.com','7785458483'),
			(5,11,3,'charlie','1998-02-17','charlie@gmail.com','9995261443'),
			(5,12,2,'jack','1987-04-24','jack@gmail.com','9994785553'),	
			(5,12,3,'rose','1981-05-26','rose@gmail.com','8541255000');
			
INSERT INTO edu_student 
	(cdept_id,college_id,roll_number,`name`,dob,gender,email,phone,address,academic_year)
	VALUES
	(1,1,'itau01','abi','1996-02-03','f','abi@gmail.com','225896','xxxxxx','2014'),
	(1,1,'itau02','anu','1995-12-22','f','anu@gmail.com','245496','xxxxxx','2018'),
	(2,1,'csau01','azar','1996-01-13','m','azar@gmail.com','525296','xxxxxx','2015'),
	(2,1,'csau02','ben','1996-12-17','m','ben@gmail.com','789566','xxxxxx','2015'),
	(3,1,'ecau01','bob','1994-08-28','m','bob@gmail.com','142554','xxxxxx','2016'),
	(3,1,'ecau02','tag','1995-09-29','m','tag@gmail.com','156234','xxxxxx','2016'),
	(4,2,'itau03','brent','1996-10-09','m','brent@gmail.com','585486','xxxxxx','2018'),
	(4,2,'itau04','iniya','1996-09-09','f','iniya@gmail.com','478566','xxxxxx','2018'),
	(5,2,'csau03','lilly','1996-05-29','f','lilly@mail.com','589527','xxxxxx','2015'),
	(5,2,'csau04','lucy','1995-05-25','f','lucy@mail.com','745897','xxxxxx','2015'),
	(6,2,'eeau01','mugil','1996-07-05','f','mugil@gmail.com','784506','xxxxxx','2017'),
	(6,2,'eeau02','megha','1995-02-04','f','megha@gmail.com','124756','xxxxxx','2017'),
	(7,3,'itpu01','elil','1995-06-18','f','elil@gmail.com','855456','xxxxxx','2018'),
	(7,3,'itpu02','gean','1996-10-18','f','gean@gmail.com','784596','xxxxxx','2018'),
	(8,3,'ecpu01','tania','1995-04-22','f','tania@gmail.com','236984','xxxxxx','2018'),
	(8,3,'ecpu02','tanisha','1995-11-20','f','tanisha@gmail.com','745001','xxxxxx','2018'),
	(9,4,'itpu03','malar','1996-11-11','f','malar@gmail.com','447856','xxxxxx','2014'),
	(9,4,'itpu04','miley','1996-12-12','f','miley@gmail.com','763294','xxxxxx','2014'),
	(10,4,'cspu01','vendy','1995-07-08','f','vendy@gmail.com','785480','xxxxxx','2015'),
	(10,4,'cspu02','vicky','1995-01-02','m','vicky@gmail.com','589640','xxxxxx','2015'),
	(11,5,'csmu01','brad','1996-10-09','m','brad@gmail.com','855556','xxxxxx','2016'),
	(11,5,'csmu02','bean','1994-10-29','m','bean@gmail.com','478566','xxxxxx','2016'),
	(12,6,'itmu01','jessica','1996-10-09','f','jessica@gmail.com','712012','xxxxxx','2017'),
	(12,6,'itmu02','jess','1995-05-05','f','jess@gmail.com','712365','xxxxxx','2017'),
	(12,6,'itmu03','july','1996-12-19','f','july@gmail.com','487597','xxxxxx','2017')
	
INSERT INTO edu_syllabus (cdept_id,syllabus_code,syllabus_name)
	VALUES
			(1,'its1','dbms'),
			(1,'its2','computer networks'),
			(2,'css1','dsp'),		
			(2,'css2','computer architecture'),	
			(3,'ecs1','circuit theory'),
			(3,'ecs2','electronic devices'),
			(4,'its2','computer networks'),
			(4,'its1','dbms'),
			(5,'css1','dsp'),
			(5,'css2','computer architecture'),
			(6,'ees1','control systems'),
			(7,'it1s','dbms'),
			(8,'ec1s','circuit theory'),
			(9,'it2s','computer networks'),
			(10,'cs1s','dsp'),
			(11,'s1cs','dsp'),
			(12,'s2it','computer networks')
			
INSERT INTO edu_professor_syllabus (emp_id,syllabus_id,semester)
	VALUES
			(2,1,4),
			(4,4,2),
			(6,5,3),
			(8,7,7),
			(10,10,2),
			(12,11,5),
			(14,12,7),
			(16,13,3),
			(18,14,6),
			(20,15,8),
			(22,16,8),
			(24,17,6);
			
INSERT INTO edu_semester_fee (cdept_id,stud_id,semester,amount,paid_year,paid_status)
	VALUES
			(1,1,2,37000,2015,'paid'),
			(1,2,7,39000,null,'unpaid'),
			(2,3,3,36000,2015,'paid'),
			(2,4,3,36000,2015,'paid'),
			(3,5,5,50000,2016,'paid'),
			(3,6,5,50000,2016,'paid'),
			(4,7,8,35000,null,'unpaid'),
			(4,8,8,35000,null,'unpaid'),
			(5,9,3,36000,2015,'paid'),
			(5,10,3,36000,2015,'paid'),
			(6,11,6,45500,null,'unpaid'),
			(6,12,6,45500,null,'unpaid'),
			(7,13,8,35000,null,'unpaid'),
			(7,14,8,35000,null,'unpaid'),
			(8,15,7,39000,null,'unpaid'),
			(8,16,7,39000,null,'unpaid'),
			(9,17,2,37000,2015,'paid'),
			(9,18,2,37000,2015,'paid'),
			(10,19,4,39000,2016,'paid'),
			(10,20,4,39000,2016,'paid'),
			(11,21,5,50000,2016,'paid'),
			(11,22,5,50000,2016,'paid'),
			(12,23,6,45500,null,'unpaid'),
			(12,24,6,45500,null,'unpaid'),
			(12,25,6,45500,null,'unpaid');
			
UPDATE edu_semester_fee SET stud_id='10' WHERE stud_id = 1 AND semester=3;
UPDATE edu_semester_fee SET paid_status ='paid' WHERE semester=6;
			
INSERT INTO edu_semester_result (stud_id,syllabus_id,semester,grade,credits,result_date)
		VALUES
				(1,1,2,'a',4,'2015-06-29'),
				(2,2,7,'a',4,'2018-01-29'),
				(3,3,3,'b',3,'2015-12-29'),
				(4,4,3,'c',2,'2016-01-29'),
				(5,5,5,'a',4,'2017-01-29'),
			   (6,5,5,'a',4,'2017-01-29'),
				(7,8,8,'d',1,'2018-06-29'), 
				(8,8,8,'d',1,'2018-06-29'),
				(9,10,3,'e',0.5,'2015-01-29'),
				(10,10,3,'e',0.5,'2015-01-29'),
				(11,11,6,'s',5,'2017-06-29'), 
				(12,11,6,'s',5,'2017-06-29'),
				(13,12,8,'a',4,'2018-06-29'), 
				(14,12,8,'a',4,'2018-06-29'),
				(15,13,7,'b',3,'2018-01-29'),
				(16,13,7,'b',3,'2018-01-29'),
				(17,14,2,'c',2,'2015-06-29'),
				(18,14,2,'c',2,'2015-06-29'), 
				(19,15,4,'d',1,'2016-06-29'), 
				(20,15,4,'d',1,'2016-06-29'),
				(21,16,5,'b',3,'2017-01-29'), 
				(22,16,5,'b',3,'2017-01-29'),
				(23,17,6,'e',0.5,'2017-06-29'),
				(24,17,6,'e',0.5,'2017-06-29'),
				(25,17,6,'e',0.5,'2017-06-29');
