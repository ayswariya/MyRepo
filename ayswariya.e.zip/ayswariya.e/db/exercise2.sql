SELECT roll_number,stu.name,stu.gender,stu.dob,stu.email,stu.phone,stu.address,col.name,dept_name
FROM edu_student AS stu
		INNER JOIN edu_college AS col ON col.id=stu.college_id
		INNER JOIN edu_university AS univ ON col.univ_code=univ.univ_code
		INNER JOIN edu_department AS dep ON univ.univ_code=dep.univ_code
		INNER JOIN edu_college_department AS coldep ON dep.dept_code=coldep.udept_code
		INNER JOIN edu_semester_fee AS semfee ON coldep.cdept_id=semfee.cdept_id
		WHERE semester IN ('7','8') AND col.name='karpagam college of engineering'
		AND col.city='coimbatore' 
		