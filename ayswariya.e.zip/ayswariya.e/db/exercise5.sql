SELECT stu.id,stu.roll_number,stu.name,stu.dob,stu.gender,stu.email,stu.phone,stu.address,stu.academic_year,
		 semres.grade,semres.credits,semres.semester,col.name
			FROM edu_student AS stu
				INNER JOIN edu_college_department AS coldep ON stu.cdept_id=coldep.cdept_id
				INNER JOIN edu_college AS col ON coldep.college_id=col.id
				INNER JOIN edu_university AS univ ON col.univ_code=univ.univ_code
				INNER JOIN edu_semester_result AS semres ON stu.id=semres.stud_id
				ORDER BY semres.semester,col.name ASC
				LIMIT 20;