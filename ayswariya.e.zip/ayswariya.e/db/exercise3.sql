SELECT stu.roll_number,stu.name,stu.gender,stu.dob,stu.email,
		 stu.phone,stu.address,col.name,dep.dept_name,emp.name
	    FROM edu_student AS stu 
	   	INNER JOIN edu_college_department AS coldep ON stu.cdept_id=coldep.cdept_id
	   	INNER JOIN edu_department AS dep ON coldep.udept_code=dep.dept_code
	   	INNER JOIN edu_university AS univ ON dep.univ_code=univ.univ_code
	   	INNER JOIN edu_college AS col ON univ.univ_code=col.univ_code
	   	INNER JOIN edu_employee AS emp ON col.id=emp.college_id
	   	INNER JOIN edu_designation AS desig ON emp.desig_id=desig.id
	   	WHERE univ.university_name='madras university' OR col.city='madras';