CREATE VIEW sem_st AS 
SELECT stu.roll_number,semfee.paid_year,semfee.paid_status
		FROM edu_student AS stu
			INNER JOIN edu_semester_fee AS semfee ON stu.id=semfee.stud_id;

SELECT * FROM sem_st;
SELECT * FROM ;


UPDATE sem_st SET paid_year='2015' , paid_status="paid" WHERE roll_number IN  ('itau01','itau02');