SELECT semfee.semester,semfee.paid_status,semfee.paid_year,col.name,col.code,univ.university_name
		FROM edu_semester_fee AS semfee 
		INNER JOIN edu_college_department AS coldep ON semfee.cdept_id=coldep.cdept_id
		INNER JOIN edu_college  AS col ON coldep.college_id=col.id
		INNER JOIN edu_university AS univ ON col.univ_code=univ.univ_code
		WHERE univ.university_name='anna university'
		ORDER BY semfee.paid_year,semfee.paid_status ASC;
		
SELECT semfee.semester,semfee.paid_status,semfee.paid_year,col.name,col.code,
		univ.university_name,semfee.amount
		FROM edu_semester_fee AS semfee 
		INNER JOIN edu_college_department AS coldep ON semfee.cdept_id=coldep.cdept_id
		INNER JOIN edu_college  AS col ON coldep.college_id=col.id
		INNER JOIN edu_university AS univ ON col.univ_code=univ.univ_code
		WHERE semfee.paid_status='paid';