import java.io.File;

public class PathAbsolute {

    public static void main(String[] args){

        File f = new File("PathAbsolute");
        String absPath = f.getAbsolutePath();
        System.out.println("Absolute path : " + absPath);
    }
}
