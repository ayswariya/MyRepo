public class VarargsExercise {

    static void display(String... name) {

        for (String studentName : name) {
            System.out.println(studentName);
        }
    }

    public static void main(String[] args) {

        display();
        display("John");
        display("Ben","Peter");
        display("Whatever");
    }
}
