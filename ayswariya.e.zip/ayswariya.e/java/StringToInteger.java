class StringToInteger {

    public static void main(String[] args) {

        String aString = "65";
        Integer StringAsInt = Integer.parseInt(aString);
        System.out.println(StringAsInt);
    }
}