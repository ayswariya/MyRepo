
public class Adder {

	public static int add(int... number) {

		int sum = 0;
		System.out.println("Number of Arguments : " + number.length);
		int NumberOfArguments = number.length;
		if (NumberOfArguments < 2) {
			System.out.println("Invalid:Enter two inputs");
		} else {
			for (int i : number) {
			sum += i;
			}
		}
		System.out.println("Sum of the Arguments : " + sum);
		return sum;
	}
	public static void main(String[] args) {

		add(1, 2, 4);
		add(3, 4, 5, 6);

	}

}
