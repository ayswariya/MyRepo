// class Concatenater {
public class Concatenater {

    // static void execute() {
    public static void main(String[] args) {

        // String hi = Hi,;
        String hi = "Hi,";
    
        // String mom = mom;
        String mom = "mom";
    
        // concatenate(string1, string2) {
            // console.print(string1 + string2);
        // }
        // concatenate(hi, mom);
        String concatenatedString = hi.concat(mom); 
        System.out.println(concatenatedString);
    
        // another way to concatenate two strings
        // console.print(String1 + String2);
        System.out.println(hi + mom);
    }
}
