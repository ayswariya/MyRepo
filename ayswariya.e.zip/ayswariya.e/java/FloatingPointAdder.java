
public class FloatingPointAdder {

	public static float add(float... number) {

		float sum = 0;
		System.out.println("Number of Arguments : " + number.length);
		int NumberOfArguments = number.length;
		if (NumberOfArguments < 2) {
			System.out.println("Invalid:Enter two inputs");
		} else {
			for (float i : number) {
			sum += i;
			}
		}
		System.out.println("Sum of the Arguments : " + sum);
		return sum;
	}
	public static void main(String[] args) {

		add(1.2f, 2.22f, 4.0f);
		add(3.23f, 4.23f, 5.2f, 6.34f);

	}

}
