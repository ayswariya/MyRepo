public class ClassFileLocationFinder {

    // static void execute() {
    public static void main(String[] args) {

        // ClassFileLocationFinder currentProgram = getCurrentProgram();
        ClassFileLocationFinder currentProgram = new ClassFileLocationFinder;

        // Class currentClass = currentProgram.getClass();
        Class currentClass = currentProgram.getClass();

        // File currentClassFile = currentClass.getFile();
        // String absolutePath = currentClassFile.getAbsolutePath();
        String absolutePath = currentClass.getProtectionDomain()
                                          .getCodeSource()
                                          .getLocation()
                                          .getFile();

        // console console = getConsole();
        // console.print(absolutePath);
        System.out.println(absolutePath + currentClass.getName() + ".class");
    }
}
