public class IntegerToString {

    public static void main(String[] args) {

        int aNumber = 65;
        String numberAsString = Integer.toHexString(aNumber);
        System.out.println("The String is :" + numberAsString);
    }
}