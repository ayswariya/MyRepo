// class Inverter {
public class Inverter {

    // static void execute() {
    public static void main(String[] args) {

        // boolean getVariable(value)
        boolean value = false;

        // console.print(value)
        System.out.println(value);

        // value = !value
        value = !value;

        // console.print(value)
        System.out.println(value);
    }
}
