//Enum enumName = {"enumValue1",
                 //"enumValue2",
                 //"enumValue3"
//}

enum SwitchState { ON,
                   OFF,
                   MID;
                 }

public class EnumValueComparator {


    //public void execute() {
    public static void main (String[] args) {

        //compareUsingOperator {
            //....
        //}

        //compareUsingEqualsMethod {
            //....
        //}

        SwitchState state = SwitchState.MID;

        //compareUsingOperator();
        //console.print(result);
        System.out.println(state == SwitchState.OFF);

        //compareUsingEqualsMethod();
        //console.print(result);
        System.out.println(state.equals(SwitchState.OFF));
    }
}
