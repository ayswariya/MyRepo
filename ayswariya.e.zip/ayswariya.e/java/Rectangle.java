public class Rectangle {

    int area(int width, int height) {
        int areaOfRectangle = width * height;
        return areaOfRectangle;
    }

    public static void main(String[] args) {

        Rectangle myRect = new Rectangle();
        System.out.println("myRect's area is " + myRect.area(20, 30));
    }
}
