class StringReference {

    public static void main(String[] args) {

        String[] students = new String[10];
        String studentName = "Peter Parker";
        students[0] = studentName;
        System.out.println(studentName);

        studentName = null;

        System.out.println(students[0]);
        System.out.println(studentName);
    }
}
