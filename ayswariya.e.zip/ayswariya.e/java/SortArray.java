import java.util.Arrays;

public class SortArray {

    public static void main(String[] args) {

        String[] cities = { "Madurai",
                            "Thanjavur",
                            "TRICHY",
                            "Karur",
                            "Erode",
                            "trichy",
                            "Salem" };

        for (int i = 0; i < cities.length; i++) {
            System.out.println(cities[i]);
        }

        Arrays.sort(cities, String.CASE_INSENSITIVE_ORDER);
        System.out.println("Sorted the cities in ascending order:");

        for (int i = 0; i < cities.length; i++) {
            System.out.println(cities[i]);
        }
        System.out.println("Printing the even indexed Strings");

        for (int i = 0; i < cities.length; i++) {
            if (i % 2 == 0) {
                System.out.println(cities[i].toUpperCase());
            }
        }
    }
}
