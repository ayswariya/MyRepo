class GetType {

    public static void main (String[] args) {

    	double a = 100 / 24
        System.out.println(a + " : type of data is " + double.class.getName());

        double b = 100.10 / 10;
        System.out.println(b + " : type of data is " + double.class.getName());

        int c = 'Z' / 2;
        System.out.println(c + " : type of data is " + int.class.getName());

        double d = 10.5 / 0.5;
        System.out.println(d + " : type of data is " + double.class.getName());

        double e = 12.4 % 5.5;
        System.out.println(e + " : type of data is " + double.class.getName());

        int f = 100 % 56;
        System.out.println(f + " : type of data is " + int.class.getName());
    }
}
