public class ObjectEqualityChecker {

    // static void execute() {
    public static void main(String[] args) {

        // String string1;
        // String string2;
        String name1 = new String("Aysh");
        String name2 = new String("Aysh");

        // compareUsingOperator {
            // ....
        // }

        // compareUsingEqualsMethod {
            // ....
        // }

        // String result = compareUsingOperator();
        boolean result = name1 == name2;
        // console.print(result);
        System.out.println(result);

        // result = compareUsingEqualsMethod();
        result = name1.equals(name2);
        // console.print(result);
        System.out.println(result);
    }
}
